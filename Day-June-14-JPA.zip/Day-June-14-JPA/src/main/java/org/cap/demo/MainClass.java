package org.cap.demo;

import java.util.Date;
import java.util.List;

import javax.transaction.Transaction;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class MainClass {

	public static void main(String[] args) {
		
		AnnotationConfiguration config=new AnnotationConfiguration();
		config.addAnnotatedClass(Customer.class);
		config.configure();
		
		//To Recreate Schema everyTime
		//new SchemaExport(config).create(true, true);
		
		
		SessionFactory sessfactory=config.buildSessionFactory();
		
		//Default session
		//sessfactory.getCurrentSession();
		/*
		Customer customer=new Customer(1001, "Annie", 23000);
		Customer customer1=new Customer( "tom", 34000);
		Customer customer2=new Customer( "jerry", 2900);
		Customer customer3=new Customer( "Jack", 12000);*/
		
	/*Customer customer=new Customer("Tom", 23000, "tom@gmail.com", new Date(), "tom12345", "North Avvenue");
		
		Customer customer1=new Customer("Jack", 2323, "jack@gmail.com", new Date(2005,11,23), "tom12345", "North Avvenue");
		Customer customer2=new Customer("Annie", 4567, "annie@gmail.com", new Date(), "tom12345", "South Avvenue");
		Customer customer3=new Customer("Jerry", 1222, "jerry@gmail.com", new Date(2005,10,23), "tom12345", "West Avvenue");
		Customer customer4=new Customer("Kamal", 500, "kamal@gmail.com", new Date(2012,3,12), "tom12345", "East Avvenue");
		
		
		Session session=sessfactory.openSession();
		org.hibernate.Transaction trans= session.beginTransaction();
		session.save(customer);
		session.save(customer1);
		session.save(customer2);
		session.save(customer3);
		session.save(customer4);
		
		
		//session.save(customer);
		trans.commit();
		session.close();*/
		
		//Read Object
		//Cust 3
		//Remove Object
		
		/*Session session=sessfactory.openSession();
		session.getTransaction().begin();
		//Customer customer=(Customer)session.get(Customer.class, 3);
		Customer customer=(Customer)session.load(Customer.class, 2);
		//session.delete(customer);
		//customer.setCustAddress("West car Street");
		customer.setCustEmail("jack123@yahoo.com");
		session.update(customer);
		
		System.out.println(customer);
		session.getTransaction().commit();
		session.close();*/
		
		
		
		//Query
		
		Session session=sessfactory.openSession();
		session.getTransaction().begin();
		
		//String hql="from Customer where regFees>2000";
		String hql="select new Customer(custId,custName,regFees) from Customer";
		Query query= session.createQuery(hql);
		
		List<Customer> customers= query.list();
		//List<String> customers= query.list();
		
		/*for(String str:customers)
			System.out.println(str);*/
		for(Customer cust:customers)
			System.out.println(cust);
		
		
		session.getTransaction().commit();
		session.close();
		
		
		
		

	}

}
