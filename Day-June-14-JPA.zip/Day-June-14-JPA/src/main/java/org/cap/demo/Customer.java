package org.cap.demo;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name="Customer_Details")
public class Customer {
	
	@Id
	@GeneratedValue
	private int custId;
	
	@Column( name="CustomerName")
	private String custName;
	private double regFees;
	
	@Column(nullable=false)
	private String custEmail;
	
	@Temporal(TemporalType.DATE)
	private Date regDate;
	
	@Transient
	private String custpassword;
	
	@Basic
	private String custAddress;

	public Customer(){}
	
	
	
	public Customer(int custId, String custName, double regFees) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.regFees = regFees;
	}



	public Customer(int custId, String custName, double regFees, String custEmail, Date regDate, String custpassword,
			String custAddress) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.regFees = regFees;
		this.custEmail = custEmail;
		this.regDate = regDate;
		this.custpassword = custpassword;
		this.custAddress = custAddress;
	}



	public Customer( String custName, double regFees, String custEmail, Date regDate, String custpassword,
			String custAddress) {
		super();
		//this.custId = custId;
		this.custName = custName;
		this.regFees = regFees;
		this.custEmail = custEmail;
		this.regDate = regDate;
		this.custpassword = custpassword;
		this.custAddress = custAddress;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public double getRegFees() {
		return regFees;
	}

	public void setRegFees(double regFees) {
		this.regFees = regFees;
	}

	public String getCustEmail() {
		return custEmail;
	}

	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}

	public Date getRegDate() {
		return regDate;
	}

	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}

	public String getCustpassword() {
		return custpassword;
	}

	public void setCustpassword(String custpassword) {
		this.custpassword = custpassword;
	}

	public String getCustAddress() {
		return custAddress;
	}

	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", regFees=" + regFees + ", custEmail="
				+ custEmail + ", regDate=" + regDate + ", custpassword=" + custpassword + ", custAddress=" + custAddress
				+ "]";
	}
	
	
	
	
	
	

}
