package org.demo.map;

import java.util.TreeMap;

public class TreeMapDemo {
	
	public static void main(String[] args) {
		
	}

}
