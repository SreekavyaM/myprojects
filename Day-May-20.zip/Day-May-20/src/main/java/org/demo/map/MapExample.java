package org.demo.map;

import java.util.HashMap;
import java.util.Map;

public class MapExample {
	public static void main(String[] args) {
		// Map<Integer, String> mp=new HashMap<>();

		HashMap<Integer, String> hmp = new HashMap<>();
		hmp.put(1, "Sreekavya");
		hmp.put(2, "Abhilash");
		hmp.put(3, "Abhishek");

		hmp.put(4, "Kumar");

		hmp.put(5, "Suchi");
		System.out.println(hmp.entrySet());
		hmp.remove(4);
		System.out.println(hmp.entrySet());
		System.out.println(hmp.containsKey(2));
		System.out.println(hmp.isEmpty());
		System.out.println(hmp.get(4));
		System.out.println(hmp.get(3));
		
		System.out.println(hmp.size());
		System.out.println(hmp.values());
		System.out.println(hmp.containsValue("Sreekavya"));
		
				
				
				
				
				
				
				
				
				
		
		
		
		
		
		
		
		
		
	}
}
