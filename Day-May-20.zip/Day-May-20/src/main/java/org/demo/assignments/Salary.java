package org.demo.assignments;

public class Salary {
	private int no_of_days;
	private double salPerDay;

	public Salary(int no_of_days, double salPerDay) {
		super();
		this.no_of_days = no_of_days;
		this.salPerDay = salPerDay;
	}

	public Salary() {
		super();
	}

	public int getNo_of_days() {
		return no_of_days;
	}

	public void setNo_of_days(int no_of_days) {
		this.no_of_days = no_of_days;
	}

	public double getSalPerDay() {
		return salPerDay;
	}

	public void setSalPerDay(double salPerDay) {
		this.salPerDay = salPerDay;
	}

	@Override
	public String toString() {
		return "Salary [no_of_days=" + no_of_days + ", salPerDay=" + salPerDay + "]";
	}

}
