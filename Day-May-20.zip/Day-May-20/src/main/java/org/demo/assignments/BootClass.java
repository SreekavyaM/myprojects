package org.demo.assignments;

import java.util.HashMap;
import java.util.Scanner;

public class BootClass {

	public static void main(String[] args) {

		UserInteraction user = new UserInteraction();

		Employee emp = null;
		Salary sal1 = null;
		Scanner s = new Scanner(System.in);
		int opt;
		for (;;) {

			System.out.println("1.To create hashmap ");
			System.out.println("2.View all hashmaps");
			System.out.println("3.Search for a key");

			opt = s.nextInt();

			HashMap<Object, Object> hp = new HashMap<>();

			switch (opt)
			{
			case 1:
				emp = user.getEmpDetails();
				sal1 = user.getSalDetails();
				hp.put(emp, sal1);

				System.out.println(hp.values());
				System.out.println(hp.get(emp));
				break;

			case 2:
				System.out.println(hp.values());
				break;
			case 3:
				System.out.println("Enter employee id");
				int e = s.nextInt();
				if (e == emp.getEmpId()) 
					System.out.println(hp.get(emp));

				
			else {
					System.out.println("Employee id is invalid");
				}
				break;
			
			}

		}

	}
}
