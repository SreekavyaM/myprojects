package org.demo.assignments;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class UserInteraction {
	
	private int empId;
	private String firstName;
	private String lastName;
	private Date dob;
	private Date doj;
	private int no_of_days;
	private double salPerDay;
	Scanner s=new Scanner(System.in);
	SimpleDateFormat sdf=new SimpleDateFormat("dd/mm/yyyy");
	Employee emp=null;
	Salary sal1=null;
	public Employee getEmpDetails()
	{
		try{
		System.out.println("Enter employee id:");
		empId=s.nextInt();
		System.out.println("Enter firstname:");
		firstName=s.next();
		System.out.println("Enter last name:");
		lastName=s.next();
		System.out.println("enter DOB in dd/mm/yyyy format");
		String st=s.next();
		dob=sdf.parse(st);
		System.out.println("enter DOJin dd/mm/yyyy format");
		String st1=s.next();
		doj=sdf.parse(st1);
		emp=new Employee(empId, st, st1, dob, doj);
			
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
		return emp;
	}
	public Salary getSalDetails()
	{
		System.out.println("Enter no of days worked");
		no_of_days=s.nextInt();
		System.out.println("Enter salary per day");
		salPerDay=s.nextDouble();
		
		sal1=new Salary(no_of_days, salPerDay);
		return sal1;
		
		
		
	}


}
