package org.demo.set;

import java.util.Comparator;

public class SortByAccno implements Comparator<AccountNew> {

	@Override
	public int compare(AccountNew o1, AccountNew o2) {
		if(o1.getAccNo()>(o2.getAccNo()))
			return 1;
		else if(o1.getAccNo()<(o2.getAccNo()))
			return -1;
		else 
		return 0;
	}

}
