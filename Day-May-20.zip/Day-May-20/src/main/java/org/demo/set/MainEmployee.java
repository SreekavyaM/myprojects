package org.demo.set;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class MainEmployee {
	
	public static void main(String[] args) {
		Employee emp1=new Employee(123, "Sreekavya", "Murali", 40000);
		Employee emp2=new Employee(124, "Libin", "Alex", 60000);
		Employee emp3=new Employee(125, "Lahari", "s", 40000);
		Employee emp4=new Employee(126, "Divya", "Sandeep", 50000);
		Employee emp5=new Employee(127, "Kalitha", "Gowda", 30000);
		
		
		Employee emp6=new Employee(125, "Lahari", "s", 40000);
		Employee emp7=new Employee(123, "Sreekavya", "Murali", 40000);
		
		
		
		//HashSet<Employee> employees=new HashSet<>();
		//LinkedHashSet<Employee> employees=new LinkedHashSet<>();
		//TreeSet<Employee> employees=new TreeSet<>();
		
		ArrayList<Employee> employees=new ArrayList<>();
		employees.add(emp1);
		employees.add(emp2);
		employees.add(emp3);
		employees.add(emp4);
		employees.add(emp5);
		employees.add(emp6);
		employees.add(emp7);
		employees.add(emp1);
		
		Collections.sort(employees,new ByEmpId());
		
		Iterator<Employee> it=employees.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		

		
		
		
	}

}
