package org.demo.set;

import java.io.Serializable;
import java.util.Scanner;

public class Address implements Serializable {
	int doorNo;
	String streetNam;
	String city;
	String state;
	
		Scanner sc=new Scanner(System.in);
		Address add1=null;
		
	public Address(int doorNo, String streetNam, String city, String state) {
			super();
			this.doorNo = doorNo;
			this.streetNam = streetNam;
			this.city = city;
			this.state = state;
		}

	public Address() {
		
	}

	public Address getAddress()
	{
		System.out.println("Enter your doorno");
	     doorNo=sc.nextInt();
	     System.out.println("Enter your street name");
	     streetNam=sc.next();
	     System.out.println("Enter your city");
	     city=sc.next();
	     System.out.println("Enter your state");
	     state=sc.next();
		return new Address(doorNo, streetNam, city, state);
		
		
	}

	public int getDoorNo() {
		return doorNo;
	}

	public void setDoorNo(int doorNo) {
		this.doorNo = doorNo;
	}

	public String getStreetNam() {
		return streetNam;
	}

	public void setStreetNam(String streetNam) {
		this.streetNam = streetNam;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	
	
	

}
