package org.demo.set;

import java.util.Comparator;

public class SortByCity implements Comparator<AccountNew> {

	@Override
	public int compare(AccountNew o1, AccountNew o2) {
		if(o1.add.getCity().compareTo(o2.add.getCity())>0)
			return 1;
		else if(o1.add.getCity().compareTo(o2.add.getCity())<0)
			return -1;
		else 
		return 0;
	}

}
