package org.demo.set;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class AccountMain {
	public static void main(String[] args) {
		Address add1 = new Address(12, "Ks layout", "Bangalore", "Karnataka");

		Address add2 = new Address(12, "Ks layout", "Bangalore", "Karnataka");
		Address add3 = new Address(20, "anjan layout", "Bangalore", "Karnataka");
		Address add4 = new Address(34, "Pattanur", "Kannur", "Kerala");
		Address add5 = new Address(23, "Aavadi", "Chennai", "Tamilnadu");
		Address add6 = new Address(17, "Kolappa", "Kannur", "Kerala");
		Address add7 = new Address(56, "kohi", "Ernakulam", "Kerala");
		Address add8 = new Address(33, "Rajaji nagar", "Bangalore", "Karnataka");
		Address add9 = new Address(199, "Mukkam", "Calicut", "Kerala");
		Address add10 = new Address(123, "Kundamangalam", "Calicut", "Kerala");

		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");

		try {
			String sdat = "10/4/2015";
			Date date1 = sdf.parse(sdat);

			String sdat1 = "10/3/2016";
			Date date2 = sdf.parse(sdat1);

			String sdat2 = "13/4/2000";
			Date date3 = sdf.parse(sdat2);

			String sdat3 = "12/7/2012";
			Date date4 = sdf.parse(sdat3);

			String sdat4 = "10/4/1999";
			Date date5 = sdf.parse(sdat4);

			String sdat5 = "12/12/1998";
			Date date6 = sdf.parse(sdat5);

			String sdat6 = "10/9/2013";
			Date date7 = sdf.parse(sdat6);

			String sdat7 = "10/9/2014";
			Date date8 = sdf.parse(sdat7);

			String sdat8 = "10/9/2013";
			Date date9;

			date9 = sdf.parse(sdat8);

			String sdat9 = "10/9/2013";
			Date date10 = sdf.parse(sdat9);

			AccountNew acc1 = new AccountNew(1, "Sree", "current", date1, 20000.95, add1);
			AccountNew acc2 = new AccountNew(2, "Libin", "current", date2, 50000, add2);
			AccountNew acc3 = new AccountNew(3, "Lahari", "current", date3, 5000.95, add3);
			AccountNew acc4 = new AccountNew(4, "Kalitha", "savings", date4, 6000, add4);
			AccountNew acc5 = new AccountNew(5, "Divya", "savings", date5, 6000, add5);
			AccountNew acc6 = new AccountNew(6, "Sandeep", "current", date6, 2000, add6);
			AccountNew acc7 = new AccountNew(7, "Somy", "savings", date7, 3000, add7);
			AccountNew acc8 = new AccountNew(8, "Remya", "savings", date8, 10000, add8);
			AccountNew acc9 = new AccountNew(9, "Kavya", "current", date9, 6000, add9);
			AccountNew acc10 = new AccountNew(10, "Kutu", "current", date10, 50000, add10);

			List<AccountNew> lst = new ArrayList<>();

			lst.add(acc1);
			lst.add(acc2);
			lst.add(acc3);
			lst.add(acc4);
			lst.add(acc5);
			lst.add(acc6);
			lst.add(acc7);
			lst.add(acc8);
			lst.add(acc9);
			lst.add(acc10);

			System.out.println("1.To sort by acc no");
			System.out.println("2.To sort by name");
			System.out.println("3.To sort by open date");
			System.out.println("4.To sort by city");
			Scanner s1 = new Scanner(System.in);
			int opt = s1.nextInt();

			if (opt == 1) {
				Collections.sort(lst, new SortByAccno());

			}
			if (opt == 2) {
				Collections.sort(lst, new SortByName());

			}
			if (opt == 3) {
				Collections.sort(lst, new SortByOpenDate());

			}
			if (opt == 4) {
				Collections.sort(lst, new SortByCity());

			}


			Iterator<AccountNew> it = lst.iterator();
			while (it.hasNext())
				System.out.println(it.next());

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
