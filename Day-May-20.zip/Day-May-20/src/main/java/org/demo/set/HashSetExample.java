package org.demo.set;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class HashSetExample {
	
	public static void main(String[] args) {
		
		//Set<String> st=new HashSet<>();
		
		//HashSet<String> hst=new HashSet<String>();
		
		//LinkedHashSet<String> hst=new LinkedHashSet<>();
		
		TreeSet<String> hst=new TreeSet<>();
		
		hst.add("Tom");
		hst.add("Tom");
		hst.add("Sam");
		hst.add("Alish");
		hst.add("George");
		hst.add("Kavya");
		//hst.add(null);
		hst.add("Sam");
		hst.add("Alish");
		hst.add("George");
		System.out.println(hst);
		
		
	//	for(String s:hst)
		//	System.out.println(s);
		
		
		Iterator<String> it=hst.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
		
	}
	
	
	
	
	
	

}
