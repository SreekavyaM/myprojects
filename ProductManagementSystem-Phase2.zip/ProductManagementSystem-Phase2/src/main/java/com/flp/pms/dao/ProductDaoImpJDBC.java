package com.flp.pms.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;

public class ProductDaoImpJDBC implements IProductDao {

	DatabaseConnections dbConnections = new DatabaseConnections();

	@Override
	public List<Category> getAllCategory() {
		List<Category> list1 = new ArrayList<>();
		String query1 = "select * from category";
		ResultSet rs = null;
		try {
			rs = dbConnections.getPreparedStatement(query1).executeQuery();
			while (rs.next()) {
				Category categories = new Category();
				categories.setCategory_Id(rs.getInt(1));
				categories.setCategory_Name(rs.getString(2));
				categories.setDescription(rs.getString(3));

				list1.add(categories);
			}
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			dbConnections.closeConnection();
		}

		return list1;
	}

	@Override
	public List<SubCategory> getAllSubCategory() {
		List<SubCategory> list2 = new ArrayList<>();

		String query2 = "select * from subcategory";

		ResultSet rs = null;
		List<Category> categories = getAllCategory();

		try {
			rs = dbConnections.getPreparedStatement(query2).executeQuery();
			while (rs.next()) {
				Category category = new Category();
				SubCategory subcategories = new SubCategory();
				subcategories.setSub_category_Id(rs.getInt(1));
				subcategories.setSub_category_Name(rs.getString(2));
				int category_Id = rs.getInt(3);
				for (Category Category2 : categories) {
					if (Category2.getCategory_Id() == category_Id) {
						category = Category2;
					}
				}
				subcategories.setCategory(category);

				list2.add(subcategories);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			dbConnections.closeConnection();
		}

		return list2;
	}

	@Override
	public List<Supplier> getAllSuppliers() {
		List<Supplier> list3 = new ArrayList<>();
		String query2 = "select * from supplier";

		ResultSet rs = null;

		try {
			rs = dbConnections.getPreparedStatement(query2).executeQuery();
			while (rs.next()) {
				Supplier supplier = new Supplier();
				supplier.setSupplier_Id(rs.getInt(1));
				supplier.setFirstName(rs.getString(2));
				supplier.setLastName(rs.getString(3));
				supplier.setAddress(rs.getString(4));
				supplier.setCity(rs.getString(5));
				supplier.setState(rs.getString(6));
				supplier.setPincode(rs.getString(7));
				supplier.setContactNo(rs.getString(8));
				list3.add(supplier);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			dbConnections.closeConnection();
		}

		return list3;
	}

	@Override
	public List<Discount> getAllDiscounts() {
		List<Discount> list4 = new ArrayList<>();

		String query2 = "select * from discount";

		ResultSet rs = null;

		try {
			rs = dbConnections.getPreparedStatement(query2).executeQuery();
			while (rs.next()) {
				Discount discount = new Discount();
				discount.setDiscount_Id(rs.getInt(1));
				discount.setDiscount_Name(rs.getString(2));
				discount.setDescription(rs.getString(3));
				discount.setDiscount_Percentage(rs.getDouble(4));
				discount.setValidThru(rs.getDate(5));
				list4.add(discount);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			dbConnections.closeConnection();
		}

		return list4;
	}

	@Override
	public void addProduct(Product product) {
		int count1 = 0;
		int count2 = 0;
		ResultSet rs = null;
		String query1 = "insert into product (productname,description,manufactrdate,expirydate,maxretailprice,category_id,subcategoryid,supplier_id,quantity,rating)values(?,?,?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement pst1 = dbConnections.getMySQlConnection().prepareStatement(query1);

			pst1.setString(1, product.getProductName());
			pst1.setString(2, product.getDescription());
			pst1.setDate(3, new java.sql.Date(product.getManufacturing_date().getTime()));
			pst1.setDate(4, new java.sql.Date(product.getExpiry_date().getTime()));
			pst1.setDouble(5, product.getMaxRetailPrice());
			pst1.setInt(6, product.getCategory().getCategory_Id());
			pst1.setInt(7, product.getSubCategory().getSub_category_Id());
			pst1.setInt(8, product.getSupplier().getSupplier_Id());
			pst1.setDouble(9, product.getQuantity());
			pst1.setFloat(10, product.getRating());

			count1 = pst1.executeUpdate();

			String query2 = "select * from product";
			PreparedStatement pst2 = dbConnections.getMySQlConnection().prepareStatement(query2);

			rs = pst2.executeQuery();

			int id = 0;
			while (rs.next()) {

				id = rs.getInt(1);
			}

			String query3 = "insert into product_discount values(?,?)";
			PreparedStatement pst3 = dbConnections.getMySQlConnection().prepareStatement(query3);

			List<Discount> discnt = product.getDiscounts();
			for (Discount discount : discnt) {

				pst3.setInt(1, id);
				pst3.setInt(2, discount.getDiscount_Id());
				count2 = pst3.executeUpdate();
			}

			System.out.println(count1);
			System.out.println(count2);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			dbConnections.closeConnection();
		}

	}

	@Override
	public List<Product> getAllProducts() {

		List<Product> productlists = new ArrayList<>();

		String query1 = "select * from product";

		ResultSet rs = null;

		List<Category> categories = getAllCategory();
		List<SubCategory> subcategories = getAllSubCategory();
		List<Supplier> suppliers = getAllSuppliers();
		List<Discount> discounts = getAllDiscounts();

		Category category = new Category();
		SubCategory scategory = new SubCategory();
		Supplier suplier = new Supplier();
		Discount discnt = new Discount();

		try {
			Statement stmt = dbConnections.getMySQlConnection().createStatement();
			rs = stmt.executeQuery(query1);

			while (rs.next()) {
				Product product = new Product();
				product.setProductId(rs.getInt(1));
				product.setProductName(rs.getString(2));
				product.setDescription(rs.getString(3));
				Date javaDate1 = new Date(rs.getDate(4).getTime());
				product.setManufacturing_date(javaDate1);
				Date javaDate2 = new Date(rs.getDate(5).getTime());
				product.setExpiry_date(javaDate2);
				product.setMaxRetailPrice(rs.getDouble(6));

				int categoryId = rs.getInt(7);
				for (Category c : categories)
					if (c.getCategory_Id() == categoryId)
						category = c;
				product.setCategory(category);

				int subId = rs.getInt(8);
				for (SubCategory sc : subcategories)
					if (sc.getSub_category_Id() == subId)
						scategory = sc;
				product.setSubCategory(scategory);

				int supplId = rs.getInt(9);
				for (Supplier sp : suppliers)
					if (sp.getSupplier_Id() == supplId)
						suplier = sp;
				product.setSupplier(suplier);

				product.setQuantity(rs.getInt(10));
				product.setRating(rs.getFloat(11));

				String query2 = "select * from product_discount where product_Id=?";

				ResultSet rs2 = null;
				PreparedStatement pst = dbConnections.getMySQlConnection().prepareStatement(query2);
				pst.setInt(1, product.getProductId());
				rs2 = pst.executeQuery();

				List<Discount> discounts2 = new ArrayList<>();

				while (rs2.next()) {
					int disId = rs2.getInt(2);
					for (Discount dis : discounts)
						if (dis.getDiscount_Id() == disId)
							discnt = dis;
					discounts2.add(discnt);
				}
				product.setDiscounts(discounts2);

				productlists.add(product);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			dbConnections.closeConnection();
		}

		return productlists;
	}

	public void deleteProduct(int productId) {
		int count1 = 0;
		int count2 = 0;

		String query1 = "DELETE FROM product WHERE productid=?";
		String query2 = "DELETE FROM product_discount WHERE product_id=?";

		try {
			PreparedStatement pstmt = dbConnections.getPreparedStatement(query1);

			pstmt.setInt(1, productId);

			count1 = pstmt.executeUpdate();

			PreparedStatement pstmt1 = dbConnections.getPreparedStatement(query2);

			pstmt1.setInt(1, productId);

			count2 = pstmt1.executeUpdate();

			if (count1 > 0 && count2 > 0)
				System.out.println("Deleted product");

		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	public void updateProductName(Product p, String name) {

		String query = "update product set productname=? where productid=?";

		try {
			PreparedStatement pstmt1 = dbConnections.getPreparedStatement(query);
			pstmt1.setString(1, name);
			pstmt1.setInt(2, p.getProductId());
			boolean b = pstmt1.execute();
			if (!b)
				System.out.println("Updated product name");
		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	public void updateProductCategory(Product p, int c) {

		String query = "update product set category_id=? where productid=?";

		try {
			PreparedStatement pstmt1 = dbConnections.getPreparedStatement(query);
			pstmt1.setInt(1,c);
			pstmt1.setInt(2, p.getProductId());
			boolean b = pstmt1.execute();
			if (!b)
				System.out.println("Updated category");
		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	public void updateManufacturingDate(Product p, Date date) {
		
		String query = "update product set manufactrdate=? where productid=?";

		try {
			PreparedStatement pstmt1 = dbConnections.getPreparedStatement(query);
			
			
			pstmt1.setDate(1,new java.sql.Date(date.getTime()));
			pstmt1.setInt(2, p.getProductId());
			boolean b = pstmt1.execute();
			if (!b)
				System.out.println("Updated manufacturing date");
		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	public void updateExpiryDate(Product p, Date date) {
		
		String query = "update product set expirydate=? where productid=?";

		try {
			PreparedStatement pstmt1 = dbConnections.getPreparedStatement(query);
			
			
			pstmt1.setDate(1,new java.sql.Date(date.getTime()));
			pstmt1.setInt(2, p.getProductId());
			boolean b = pstmt1.execute();
			if (!b)
				System.out.println("Updated expiry date");
		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	public void updateMaxRetailPrice(Product p, double mrp) {
		String query = "update product set maxretailprice=? where productid=?";

		try {
			PreparedStatement pstmt1 = dbConnections.getPreparedStatement(query);
			
			
			pstmt1.setDouble(1, mrp);
			pstmt1.setInt(2, p.getProductId());
			boolean b = pstmt1.execute();
			if (!b)
				System.out.println("Updated max retail price");
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

}
