package org.thread.assignments;

public class MultiplicationMain {
	public static void main(String[] args) {
		
	MultiplicationTable t1=new MultiplicationTable(5);
	MultiplicationTable t2=new MultiplicationTable(10);
	MultiplicationTable t3=new MultiplicationTable(15);
	
	
	t1.start();
	t1.setPriority(10);
	
	t2.start();
	t2.setPriority(Thread.MAX_PRIORITY);
	
	
	/*try {
		t1.join();
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}*/
	
	t3.start();
	t3.setPriority(Thread.MIN_PRIORITY);
	
	}
}
