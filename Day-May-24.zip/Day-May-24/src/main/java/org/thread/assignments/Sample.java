package org.thread.assignments;

public class Sample extends Thread {
	private String name;

	public Sample() {
		

	}

	synchronized static public void printName(String name) {

	
		
	for (int i = 0; i <= name.length(); i++) {
			for (int j = 0; j < i; j++) {
				System.out.print(name.charAt(j));

			}
			System.out.println();
		}
		

	}

}
