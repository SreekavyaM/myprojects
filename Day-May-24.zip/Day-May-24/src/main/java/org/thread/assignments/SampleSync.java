package org.thread.assignments;

import org.cap.Thread.MultiplyTable;

public class SampleSync {
	public static void main(String[] args) {
final Sample obj=new Sample();
		
		Thread t1=new Thread(){
			
			public void run(){
				
				//obj.printName("CAPGEMINI");
				Sample.printName("Capgemini");
				
			}
		};
		
		Thread t2=new Thread(){
			
			public void run(){
				//obj.printName("SREEKAVYA");
				Sample.printName("Sreekavya");
			}
		};
		
		
		
		Thread t3=new Thread(){
			
			public void run(){
				//obj.printName("WELCOME");
				Sample.printName("welcome");
			}
		};
		
		
		t1.start();
		t2.start();
		t3.start();
	}

}
