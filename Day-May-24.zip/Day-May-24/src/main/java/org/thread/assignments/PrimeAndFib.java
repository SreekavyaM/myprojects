package org.thread.assignments;

import java.util.ArrayList;

public class PrimeAndFib {

	ArrayList<Integer> l1 = new ArrayList<Integer>();

	public void fibo() {
		int first = 0;
		int second = 1;
		int next = 1;
		int sum = 0;
		// System.out.println(first);
		// System.out.println(second);

		while (sum < 100000) {
			next = first + second;
			sum = next;
			first = second;
			second = next;
			// System.out.println(sum);
			l1.add(sum);

		}

	}

	ArrayList<Integer> l2 = new ArrayList<Integer>();

	public void primeNum() {
		// define limit
		int limit = 100000;

		// loop through the numbers one by one
		for (int i = 2; i < 100000; i++) {

			boolean isPrime = true;

			// check to see if the number is prime
			for (int j = 2; j < i; j++) {

				if (i % j == 0) {
					isPrime = false;
					break;
				}
			}
			// print the number
			if (isPrime)
				// System.out.println(i);
				l2.add(i);
		}
	}

	ArrayList<Integer> l3 = new ArrayList<Integer>();

	public void compareFibPrime() {

		System.out.println("Identified common numbers....");
		for (int i : l1)
			for (int j : l2)
				if (i == j) {
					l3.add(i);
					System.out.println(i);
				}

	}

}
