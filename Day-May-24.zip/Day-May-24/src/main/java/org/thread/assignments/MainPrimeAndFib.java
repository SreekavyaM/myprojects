package org.thread.assignments;

import org.cap.Thread.MultiplyTable;

public class MainPrimeAndFib {
	public static void main(String[] args) {
		final PrimeAndFib pr = new PrimeAndFib();

		Thread t1 = new Thread() {

			public void run() {
				pr.fibo();
			}
		};

		Thread t2 = new Thread() {

			public void run() {
				pr.primeNum();
			}
		};

		Thread t3 = new Thread() {

			public void run() {
				pr.compareFibPrime();
			}
		};

		t1.start();
		try {
			t1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		t2.start();
		try {
			t2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		t3.start();
	}

}
