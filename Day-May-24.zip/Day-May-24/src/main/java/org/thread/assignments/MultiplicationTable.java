package org.thread.assignments;

public class MultiplicationTable extends Thread {
	
	private int num;
	public MultiplicationTable(int num)
	{
		this.num=num;
	}
	public void run() {
		try {
			for (int i = 0; i <15; i++) {
				System.out.println(currentThread().getName()+"-->"+i + "*"+num+"=" + i * num);
			
			Thread.sleep(1000);
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
