package org.thread.assignments;

public class MainSample {
	public static void main(String[] args) {
		Sample s1=new Sample();
		Sample s2=new Sample();
		Sample s3=new Sample();
		
		s1.start();
		s2.start();
		s3.start();
	}

}
