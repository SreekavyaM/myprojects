package org.sample;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Sample {
	public static void main(String... args) {
		HashMap<String, Integer> companyDetails = new HashMap<String, Integer>();
 
		// create hashmap with keys and values (CompanyName, #Employees)
		companyDetails.put("eBay", 4444);
		companyDetails.put("Paypal", 5555);
		companyDetails.put("IBM", 6666);
		companyDetails.put("Google", 7777);
		companyDetails.put("Yahoo", 8888);
 
		System.out.println("==> Size of companyDetails Map: " + companyDetails.size());
		Iterator it = companyDetails.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry pairs = (Map.Entry) it.next();
			System.out.println(pairs.getKey() + " = " + pairs.getValue());
		}
 

}
}
