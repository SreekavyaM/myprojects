package org.sample;


	
	import static java.lang.System.out;
	import java.util.Collections;
	import java.util.NavigableSet;
	import java.util.TreeSet;
	public class Test {
	public static void main(String[] args) {
	NavigableSet<String> strSetA = new TreeSet<String>();
	Collections.addAll(strSetA, "set", "shell", "soap");
	System.out.println(strSetA);
	out.print(strSetA.ceiling("shell") + " ");
	System.out.println(strSetA);
	out.print(strSetA.floor("shell") + " ");
	out.print(strSetA.higher("shell") + " ");
	out.println(strSetA.lower("shell"));
	}
	

	

}
