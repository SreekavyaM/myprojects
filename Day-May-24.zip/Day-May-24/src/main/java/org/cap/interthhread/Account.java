package org.cap.interthhread;

public class Account {
private double bal=10000;
	
	
	synchronized public void withdraw(double balance){
		
		if(this.bal<balance)
		{
			System.out.println("Insufficient balance!Waiting for deposited...");
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		this.bal-=balance;
		System.out.println("Balance withdrew. Current balance=" + this.bal);
		
	}
		synchronized public void deposit(double balance){
			System.out.println("Producer Started!");
			this.bal+=balance;
			System.out.println("Prodcut Produced. Updated Quantity=" + this.bal);
			
			notifyAll();
			
		}

	}

