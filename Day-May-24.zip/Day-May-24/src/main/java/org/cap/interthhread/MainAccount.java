package org.cap.interthhread;

public class MainAccount {
	public static void main(String[] args) {
		
	
	final Account acc=new Account();
	
	Thread t1=new Thread(){
		@Override
		public void run(){
			acc.withdraw(5000);
		}
	};
	
	Thread t2=new Thread(){
		@Override
		public void run(){
			acc.deposit(2000);
		}
	};
	
	Thread t3=new Thread(){
		@Override
		public void run(){
			acc.withdraw(4000);
		}
	};
	
	
	
	
	t1.start();
	t2.start();
	t3.start();

}

}
