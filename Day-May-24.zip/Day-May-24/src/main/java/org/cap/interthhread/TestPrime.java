package org.cap.interthhread;

public class TestPrime {
	public static void main(String[] args) {
		TestPrime t=new TestPrime();
		t.fibo();
	}
		

		public void fibo() {
			int first = 0;
			int second = 1;
			int next = 1;
			int sum = 0;
			System.out.println(first);
			System.out.println(second);

			while (sum < 100000) {
				next = first + second;
				sum = next;
				first = second;
				second = next;
				System.out.println(sum);
				
			}
			
		
		}
		
		
		
      /*  //define limit
        int limit = 100000;
       
        //loop through the numbers one by one
        for(int i=2; i < 100000; i++){
               
                boolean isPrime = true;
               
                //check to see if the number is prime
                for(int j=2; j < i ; j++){
                       
                        if(i % j == 0){
                                isPrime = false;
                                break;
                        }
                }
                // print the number
                if(isPrime)
                        System.out.println(i);
        }
*/

}
