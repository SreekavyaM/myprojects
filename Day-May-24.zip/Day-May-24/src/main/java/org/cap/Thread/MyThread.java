package org.cap.Thread;

public class MyThread extends Thread{
	public MyThread(String threadName)
	{
		super(threadName);
	}
	
	public void run(){
		
		
		System.out.println("Thread started");
		for(int i=0;i<20;i++)
		{
			System.out.println(currentThread().getName()+"---->"+i);
		}
	}

}
