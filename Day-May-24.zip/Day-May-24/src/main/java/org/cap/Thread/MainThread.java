package org.cap.Thread;

public class MainThread {
	public static void main(String[] args) {
		MyThread t1=new MyThread("first");
		t1.start();//thread is moving from runnable to running state
		MyThread t2=new MyThread("second");
		t2.start();
	}

}
