package org.cap.Thread;

public class MainRun {
	public static void main(String[] args) {
		MyThreadRun run = new MyThreadRun();
		Thread t1=new Thread(run,"first");
		t1.start();
		Thread t2=new Thread(run,"second");
		t2.start();
	}
}
