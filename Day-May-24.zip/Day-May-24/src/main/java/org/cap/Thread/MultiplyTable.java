package org.cap.Thread;

public class MultiplyTable extends Thread{
	/*private int num;
	public MultiplyTable(int num)
	{
		this.num=num;
	}*/
	public void printTable(int num){
		for(int i=1;i<=15;i++)
		{
			System.out.println(Thread.currentThread().getName()+"---->"+i+"*"+num+"="+i*num);
		}
	}
	/*@Override
	public void run() {
		printTable();
	}
*/
}
