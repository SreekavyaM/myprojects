package org.cap.Thread;

public class MainMultiply {
	public static void main(String[] args) {
		/*MultiplyTable m1=new MultiplyTable(5);
		MultiplyTable m2=new MultiplyTable(10);
		MultiplyTable m3=new MultiplyTable(15);
		
		m1.start();
		m2.start();
		m3.start();*/
		final MultiplyTable obj=new MultiplyTable();
		Thread t1=new Thread()
		{
			public void run(){
				obj.printTable(10);
			}
		};
		
	}

}
