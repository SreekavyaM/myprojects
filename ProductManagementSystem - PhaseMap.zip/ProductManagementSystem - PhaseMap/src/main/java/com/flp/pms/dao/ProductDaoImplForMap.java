package com.flp.pms.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.IProductServiceImp;

public class ProductDaoImplForMap implements IProductDao {

	Map<Integer, Product> products = new HashMap<>();

	// Getting all categories
	public List<Category> getAllCategory() {
		List<Category> categories = new ArrayList<>();

		categories.add(new Category(1, "Electronics", "Electronics items"));
		categories.add(new Category(2, "HealthCare", "Medical items"));
		categories.add(new Category(3, "Sports&games", "sports items"));
		categories.add(new Category(4, "Household", "Household items"));
		categories.add(new Category(5, "Cloth", "Dress materials"));
		return categories;
	}

	// Getting all subcategories
	@Override
	public List<SubCategory> getAllSubCategory() {
		List<SubCategory> subcategories = new ArrayList<>();
		subcategories.add(new SubCategory(101, "1.Mobilephone", new Category(1, "Electronics", "Electronics items")));
		subcategories.add(new SubCategory(102, "2.Radio", new Category(1, "Electronics", "Electronics items")));
		subcategories.add(new SubCategory(103, "3.Television", new Category(1, "Electronics", "Electronics items")));
		subcategories.add(new SubCategory(104, "1.Kurtis", new Category(5, "Cloth", "Dress materials")));
		subcategories.add(new SubCategory(105, "2.Leggins", new Category(5, "Cloth", "Dress materials")));
		subcategories.add(new SubCategory(106, "3.Churidar", new Category(5, "Cloth", "Dress materials")));

		return subcategories;

	}

	// Getting all suppliers
	@Override
	public List<Supplier> getAllSuppliers() {
		List<Supplier> suppliers = new ArrayList<>();
		suppliers.add(
				new Supplier(100, "Keshav", "Lnj", "Basavanagudi", "Bangalore", "Karnataka", "12343", "9300123423"));
		suppliers
				.add(new Supplier(200, "Praveen", "D", "Chithradurga", "Bangalore", "Karnataka", "65547", "545676712"));
		suppliers.add(new Supplier(300, "Lahari", "nags", "aashram", "Bangalore", "Karnataka", "67874", "5498096712"));
		suppliers.add(new Supplier(400, "Gagan", "kavya", "hussan", "Bangalore", "Karnataka", "534762", "9840234536"));
		suppliers.add(
				new Supplier(500, "Raghu", "ram", "Chithradurga", "Bangalore", "Karnataka", "789120", "9678348965"));

		return suppliers;
	}

	// Getting all discounts
	public List<Discount> getAllDiscounts() {
		List<Discount> discounts = new ArrayList<>();
		discounts
				.add(new Discount(123, "Mega offer", "Mega offer from jan to feb", 12.4, new Date(2009 - 1900, 4, 12)));
		discounts.add(new Discount(333, "Dewali Offer", "Dewali offer ", 12.4, new Date(2018 - 1900, 4, 23)));
		discounts.add(new Discount(678, "New Year Offer", "New Year offer ", .50, new Date(2020 - 1900, 4, 23)));
		discounts.add(new Discount(1234, "X'Mas Offer", "Xmas offer ", .55, new Date(2019 - 1900, 4, 23)));
		discounts.add(new Discount(340, "Pongal Offer", "Pongal offer ", 12.78, new Date(2017 - 1900, 4, 23)));

		return discounts;
	}

	// Saving product in map
	@Override
	public void addProduct(Product product) {
		products.put(product.getProductId(), product);
	}

	// Getting all products
	@Override
	public Map<Integer, Product> getAllProducts() {

		return products;
	}

}
