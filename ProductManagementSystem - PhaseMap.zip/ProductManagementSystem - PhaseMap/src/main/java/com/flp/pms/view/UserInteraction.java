package com.flp.pms.view;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.flp.pms.dao.ProductDaoImplForMap;
import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;
import com.flp.pms.service.IProductServiceImp;
import com.flp.pms.util.Validate;

public class UserInteraction {
	Scanner sc = new Scanner(System.in);
	Product product = new Product();
	boolean flag = false;

	// Prompting product details and adding product
	public Product addProduct(List<Category> categories, List<SubCategory> subCategories, List<Discount> discounts,
			List<Supplier> suppliers) {

		String productName;
		String manufactur_date;
		String exDate;
		float rating;
		String contactNo;

		do {
			System.out.println("Enter ProductNmae");
			productName = sc.nextLine();
			flag = Validate.isValidProductName(productName);
			if (!flag)
				System.out.println("Invalid productname");
		} while (!flag);

		product.setProductName(productName);

		System.out.println("Enter product description");
		String description = sc.nextLine();
		product.setDescription(description);

		do {
			System.out.println("Enter manufacturing Date");
			manufactur_date = sc.nextLine();
			flag = Validate.isValidDate(manufactur_date);
			if (!flag)
				System.out.println("Invalid manufacturing Date");
		} while (!flag);

		product.setManufacturing_date(new Date(manufactur_date));
		// check valid expiry date

		// validate date format

		do {
			System.out.println("Enter expiry date:[dd-MMM-yyyy]");
			exDate = sc.nextLine();
			flag = Validate.isValidExpiryDate(exDate);
			if (!flag)
				System.out.println("Invalid Expiry Date");
		} while (!flag);

		product.setExpiry_date(new Date(exDate));

		// prompt max retail price
		System.out.println("Enter max retail price");
		double price = sc.nextDouble();
		product.setMaxRetailPrice(price);

		// prompt quantity
		int quantity = 0;
		do {
			System.out.println("Enter product quantity");
			quantity = sc.nextInt();
			flag = Validate.isvalidQuantity(quantity);
			if (!flag)
				System.out.println("Quantity should be positive integer");
		} while (!flag);
		product.setQuantity(quantity);

		do {
			System.out.println("Enter Rating");
			rating = sc.nextFloat();

			flag = Validate.isValidRating(rating);
			if (!flag)
				System.out.println("Rating should be between 1.0 and 5.0");
		} while (!flag);

		product.setRating(rating);

		// prompt valid category Details
		Category category = getCategory(categories);
		product.setCategory(category);

		// Prompt SubCategory Details
		SubCategory subCategory = getSubCategory(subCategories, category);
		product.setSubCategory(subCategory);

		// Prompt Dicsount Details
		List<Discount> discounts2 = getDiscounts(discounts);
		product.setDiscounts(discounts2);

		// Prompt supplier Details
		Supplier supplier = getSupplier(suppliers);
		product.setSupplier(supplier);
		IProductServiceImp iProductService = new IProductServiceImp();
		product.setProductId(iProductService.generateProductId());
		return product;
	}

	// Delete product
	public int deleteProductDetails() {

		System.out.println("Enter Productid");
		int productId = sc.nextInt();
		return productId;

	}

	// Search product
	public String searchByProductName() {
		System.out.println("Enter product name");
		String productname = sc.next();
		return productname;
	}

	public String searchBySupplier() {
		System.out.println("Enter supplier name");
		String supplierName = sc.next();
		return supplierName;
	}

	public String searchByCategory() {
		System.out.println("Enter cateogory name:");
		String categoryName = sc.next();
		return categoryName;
	}

	public String searchBySubcategory() {
		System.out.println("Enter Subcateogory name:");
		String subcategoryName = sc.next();
		return subcategoryName;
	}

	public float searchByRating() {
		System.out.println("Enter rating:");
		float rating = sc.nextFloat();
		return rating;
	}

	// prompting product id to update product
	public int getProductIdToUpdate() {
		System.out.println("Do you want to update product");
		System.out.println("Enter product id");
		int pId = sc.nextInt();
		return pId;
	}

	public String updateProductName() {
		String productname;
		do {
			System.out.println("Enter product name to be updated");
			productname = sc.next();
			flag = Validate.isValidProductName(productname);
			if (!flag)
				System.out.println("Invalid productname");
		} while (!flag);
		return productname;

	}

	public Date updateManufacturingDate() {
		System.out.println("Enter new manufacturing date:[dd-MMM-yyyy]");
		String mfgDate = sc.next();
		return new Date(mfgDate);
	}

	public Date updateExpiryDate() {
		System.out.println("Enter new Expiry date");
		String expiryDate = sc.next();
		return new Date(expiryDate);
	}

	public double updateMaxRetailPrice() {
		System.out.println("Enter new max retail price");
		double mrp = sc.nextDouble();
		return mrp;
	}

	// choose category
	public Category getCategory(List<Category> categories) {
		Scanner sc = new Scanner(System.in);
		int choice;
		boolean flag = false;
		Category category = null;
		System.out.println("choose categoryId");
		if(categories!=null){
			for (Category category1 : categories)
				System.out.println(category1.getCategory_Id() + "\t" + category1.getCategory_Name() + "\t"
						+ category1.getDescription());
			choice = sc.nextInt();

			for (Category category1 : categories) {
				if (choice == category1.getCategory_Id()) {
					category = category1;
					flag = true;
					break;
				}
			}
		}
		if (!flag)
			System.out.println();
		return category;
	}

	// Choose Sub Category
	public SubCategory getSubCategory(List<SubCategory> categories, Category category) {
		SubCategory subCategory = null;
		Scanner scanner = new Scanner(System.in);
		int option;
		boolean flag = false;

		do {
			System.out.println("Choose Product Sub Category:");
			for (SubCategory subCategory2 : categories) {
				if (subCategory2.getCategory().getCategory_Id() == category.getCategory_Id())
					System.out.println(subCategory2.getSub_category_Id() + "\t" + subCategory2.getSub_category_Name());
			}
			option = scanner.nextInt();

			// Check Valid SubCategory
			for (SubCategory subCategory2 : categories) {
				if (option == subCategory2.getSub_category_Id()) {
					subCategory = subCategory2;
					flag = true;
					break;
				}
			}

			if (!flag)
				System.out.println("* Please choose valid Sub category!");

		} while (!flag);

		return subCategory;
	}

	/**
	 * 
	 * @param discounts
	 * @return
	 */
	public List<Discount> getDiscounts(List<Discount> discounts) {
		List<Discount> discounts2 = new ArrayList<Discount>();
		Scanner sc = new Scanner(System.in);
		int option = 0;
		boolean flag = false;
		String choice = null;

		do {
			flag = false;
			do {
				System.out.println("Choose Dicounts for the Product:");
				for (Discount discount : discounts) {
					// check valid discounts
					if (discount.getValidThru().after(new Date())) {
						// System.out.println(discount.getValidThru());
						System.out.println(discount.getDiscount_Id() + "\t" + discount.getDiscount_Name() + "\t"
								+ discount.getDescription() + "\t" + discount.getDiscount_Percentage());
					}

				}
				option = sc.nextInt();

				// Validate Discount
				L3: for (Discount discount : discounts) {
					if (discount.getDiscount_Id() == option) {
						discounts2.add(discount);
						flag = true;
						break L3;
					}
				}

				if (!flag)
					System.out.println("* Choose Valid Discount Id!");

			} while (!flag);

			System.out.println("You wish to add more discounts for this product?[Y|N]");
			choice = sc.next();

		} while (choice.charAt(0) == 'y' || choice.charAt(0) == 'Y');

		return discounts2;
	}

	// Choose Supplier
	public Supplier getSupplier(List<Supplier> suppliers) {
		Supplier supplier = null;
		Scanner scanner = new Scanner(System.in);
		int option;
		boolean flag = false;

		do {
			System.out.println("Choose Supplier:");

			for (Supplier supplier1 : suppliers)
				System.out.println(supplier1.getSupplier_Id() + "\t" + supplier1.getFirstName() + "\t"
						+ supplier1.getLastName() + "\t" + supplier1.getAddress() + "\t" + supplier1.getCity() + "\t"
						+ supplier1.getPincode() + "\t" + supplier1.getState() + "\t" + supplier1.getContactNo());
			option = scanner.nextInt();

			for (Supplier supplier1 : suppliers) {
				if (option == supplier1.getSupplier_Id()) {
					supplier = supplier1;
					flag = true;
					break;
				}
			}
			if (!flag)
				System.out.println("Please choose valid supplier id");

		} while (!flag);

		return supplier;
	}

}
