package com.flp.pms.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Validate {
	public static boolean isValidProductName(String productName)
	{
		return productName.matches("[A-Z][a-z1-9_$ ]*");
	}
	
	public static boolean isValidDate(String manufactur_date )
	{
		return manufactur_date.matches("([0-3][1-9]|10|20|30)-(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)-[12][7890]\\d{2}");
		
	}
	public static boolean isValidExpiryDate(String exdate )
	{


		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
		Date date = new Date();
		String curdate = "";
		Date currntdate = null;
		Date expiry_date = null;
		try {
			curdate = sdf.format(date);
			currntdate = sdf.parse(curdate);
			expiry_date = sdf.parse(exdate);

		} catch (ParseException e) {

			e.printStackTrace();
		}
		if (expiry_date.after(currntdate))
			return true;
		else
			return false;
	}
	
	public static boolean isValidRating(float rating)
	{
		if(rating>=0.0 && rating<=5.0)
			return true;
		else
			return false;
	}
	public static boolean isValidContactNo(String contactNo)
	{
		return contactNo.matches("\\d{10}");
	}
	
	public static boolean isvalidQuantity(int quantity)
	{
		if(quantity>0)
			return true;
		else
			return false;
	}
	
}
