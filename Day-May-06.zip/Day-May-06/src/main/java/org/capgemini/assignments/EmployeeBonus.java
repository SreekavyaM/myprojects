package org.capgemini.assignments;

import java.util.Scanner;

public class EmployeeBonus {
	private String name;
	private double sal;

	public void getDetails() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the name:");
		String name = sc.nextLine();

		System.out.println("Enter the salary:");
		double sal = sc.nextDouble();
		System.out.println("Employee name:" + name);
		System.out.println("Employee salary:" + sal);
	}

	public double calcBonus() {
		double bonus = 0.0;
		if (sal > 2000000) {
			bonus = sal * 15 / 100;
		}

		if (sal > 1000000) {
			bonus = sal * 20 / 100;
		}
		if (sal > 500000) {
			bonus = sal * 25 / 100;
		} else {
			bonus = sal * 30 / 100;
		}
		return bonus;

	}

	public void showEmpDetails() {

		System.out.println("Bonus is:" + calcBonus());
	}

}
