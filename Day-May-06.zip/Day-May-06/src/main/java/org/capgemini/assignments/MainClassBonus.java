package org.capgemini.assignments;

public class MainClassBonus {
	public static void main(String[] args) {
		

	EmployeeBonus bonus=new EmployeeBonus();
	bonus.getDetails();
	bonus.showEmpDetails();
	
	
	}
}
