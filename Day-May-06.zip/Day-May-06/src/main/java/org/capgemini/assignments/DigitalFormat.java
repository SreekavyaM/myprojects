package org.capgemini.assignments;

import java.util.Scanner;

public class DigitalFormat {

	public void digital() {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number");
		int x = sc.nextInt();

		if (x == 0) {
			for (int i = 0; i < 5; i++) {
				for (int j = 0; j < 5; j++) {

					if (i == 0 || i == 4 || j == 0 || j == 4) {
						System.out.print("*");
					} else {
						System.out.print(" ");
					}

				}
				System.out.println();
			}
		}

		if (x == 1) {

			for (int i = 0; i < 5; i++) {
				for (int j = 0; j < 5; j++) {

					if (j == 3) {
						System.out.print("*");
					} else {
						System.out.print(" ");
					}

				}
				System.out.println();
			}
		}

		if (x == 2) {
			for (int i = 0; i < 5; i++) {
				for (int j = 0; j < 5; j++) {

					if (i == 0 || i == 4 || i == 2 || (j == 0 && i >= 2) || (j == 4 && i <= 2)) {
						System.out.print("*");
					} else {
						System.out.print(" ");
					}

				}
				System.out.println();
			}
		}

		if (x == 3) {
			for (int i = 0; i < 5; i++) {
				for (int j = 0; j < 5; j++) {

					if (i == 0 || i == 4 || j == 4 || i == 2) {
						System.out.print("*");
					} else {
						System.out.print(" ");
					}

				}
				System.out.println();
			}
		}

		if (x == 4) {
			for (int i = 0; i < 5; i++) {
				for (int j = 0; j < 5; j++) {

					if (i == 2 || j == 4 || (i <= 2 && j == 0)) {
						System.out.print("*");
					} else {
						System.out.print(" ");
					}

				}
				System.out.println();
			}
		}

		if (x == 5) {
			for (int i = 0; i < 5; i++) {
				for (int j = 0; j < 5; j++) {

					if (i == 0 || i == 4 || i == 2 || (j == 0 && i <= 2) || (j == 4 && i >= 2)) {
						System.out.print("*");
					} else {
						System.out.print(" ");
					}

				}
				System.out.println();
			}
		}

		if (x == 6) {
			for (int i = 0; i < 5; i++) {
				for (int j = 0; j < 5; j++) {

					if (i == 0 || i == 4 || i == 2 || (i >= 2 && j == 4) || j == 0) {
						System.out.print("*");
					} else {
						System.out.print(" ");
					}

				}
				System.out.println();
			}
		}

		if (x == 7) {
			for (int i = 0; i < 5; i++) {
				for (int j = 0; j < 5; j++) {

					if (i == 0 || j == 4) {
						System.out.print("*");
					} else {
						System.out.print(" ");
					}

				}
				System.out.println();
			}
		}

		if (x == 8) {
			for (int i = 0; i < 5; i++) {
				for (int j = 0; j < 5; j++) {

					if (i == 0 || i == 2 || i == 4 || j == 0 || j == 4) {
						System.out.print("*");
					} else {
						System.out.print(" ");
					}

				}
				System.out.println();
			}
		}

		if (x == 9) {
			for (int i = 0; i < 5; i++) {
				for (int j = 0; j < 5; j++) {

					if (i == 0 || i == 4 || j == 4 || (j == 0 && i < 3) || i == 2) {
						System.out.print("*");
					} else {
						System.out.print(" ");
					}

				}
				System.out.println();
			}
		}
	}

}
