package org.capgemini.assignments;

public class MainDigital {
	public static void main(String[] args) {
		
	
	DigitalFormat digitalFormat=new DigitalFormat();
	digitalFormat.digital();

	}
}
