package org.capgemini.assignments;

import java.util.Scanner;

public class BiggestNumber {
	public void big() {
		Scanner s1 = new Scanner(System.in);
		System.out.println("Enter first number:");
		int x = s1.nextInt();
		System.out.println("Enter second number:");
		int y = s1.nextInt();
		System.out.println("Enter third number:");
		int z = s1.nextInt();

		if (x > y && x > z) {
			System.out.println("Biggest number is:" + x);
		}
		if (y > x && y > z) {
			System.out.println("Biggest number is:" + y);
		}
		if (z > x && z > y) {
			System.out.println("Biggest number is:" + z);
		}

	}

}
