package org.capgemini.assignments;

public class MainClassBig {
	public static void main(String[] args) {
		BiggestNumber biggestNumber=new BiggestNumber();
		biggestNumber.big();
	}

}
