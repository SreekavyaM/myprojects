package org.capgemini.assignments;

public class ArmstrongNumber {

	public void armstrongNum() {
		for (int i = 1; i < 1000; i++) {
			armstrongNum(i);

		}
	}

	public void armstrongNum(int n) {
		int original = n;
		int res = 0;
		while (n > 0) {
			int remainder = n % 10;
			res = res + (remainder * remainder * remainder);
			n = n / 10;
		}
		if (original == res) {
			System.out.println(res + " ");
		}
	}

}
