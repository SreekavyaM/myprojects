package org.capgemini.assignments;

import java.util.Scanner;

public class NumberToWord {
	
		int number;
		Scanner sc = new Scanner(System.in);
		void getDigitalNumber()
		{
			System.out.println("Enter the Digital number");
			number = sc.nextInt();
		}
		
		void getWordFormat()
		{
			int r,sum=0;
			while(number!=0)
			{
				r = number%10;
				number =number/10;
				sum = sum*10+r;		
			}
			
			for(int i=1;i<=4;i++)
			{
				r=sum%10;
				sum=sum/10;
				switch (r) {
				case 0:System.out.print("Zero\t");		
					break;
					
				case 1:System.out.print("One\t");
				
				break;
				case 2:if(i==3)
					System.out.print("Twenty\t");
				else
					System.out.print("Two\t");
				
				break;
				case 3:if(i==3)
					System.out.print("Thirty\t");
				else
					System.out.print("Three\t");
				
				break;
				case 4:if(i==3)
					System.out.print("Fourty\t");
				else
					System.out.print("Four\t");
				
				break;
				case 5:if(i==3)
					System.out.print("Fifty\t");
				else
					System.out.print("Five\t");
				
				break;
				case 6:if(i==3)
					System.out.print("Sixty\t");
				else
					System.out.print("Six\t");
				
				break;
				case 7:if(i==3)
					System.out.print("Seventy\t");
				else
					System.out.print("Seven\t");
				
				break;
				case 8:if(i==3)
					System.out.print("Eighty\t");
				else
					System.out.print("Eight\t");
				
				break;
				case 9:if(i==3)
					System.out.print("Ninty\t");
				else
					System.out.print("Nine\t");
				
				break;
			}
				
				if(i==1)
				System.out.print("Thousand\t");
				else if(i==2)
					System.out.print("Hundred and\t");
				else if(i==4)
					System.out.print("only\t");
			}
		
		
		
		
		
	}

}
