package org.capgemini.assignments;

public class NumberWord {
	
	static String one[]={" ","one","two","three","four","five","six","seven","eight","nine","ten","eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","nineteen"};
	
	
	static String ten[]={" "," ","twenty","thirty","fourty","fifty","sixty","seventy","eighty","ninety"};
	
	
	
	
	
	

}
