package org.capgemini.assignments;

public class MainNumber {
	public static void main(String[] args) {
		NumberToWord numberToWord=new NumberToWord();
		numberToWord.getDigitalNumber();
		numberToWord.getWordFormat();
	}

}
