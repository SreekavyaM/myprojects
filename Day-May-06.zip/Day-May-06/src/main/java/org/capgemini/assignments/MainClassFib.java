package org.capgemini.assignments;

public class MainClassFib {
	public static void main(String[] args) {
		
		Fibonnocci fibonnocci=new Fibonnocci();
		fibonnocci.fibo(0, 1);
		
	}
	
}
