package org.capgemini.assignments;

public class MainClassArmstrong {
	public static void main(String[] args) {
		ArmstrongNumber armstrongNumber=new ArmstrongNumber();
		armstrongNumber.armstrongNum();
	}

}
