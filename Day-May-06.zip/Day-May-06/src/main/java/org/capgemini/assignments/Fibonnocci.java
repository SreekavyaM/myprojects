package org.capgemini.assignments;

public class Fibonnocci {
	
		int first=0;
		int second=1;
		int next=1;
		int sum=0;
		int fibo(int first,int second)
		{
			System.out.println(first);
			System.out.println(second);
			
			while(sum<100000)
			{
			next=first+second;
			sum=next;
			first=second;
			second=next;
			System.out.println(sum);
			}
			return sum;
			
		}
		
		
		
	

}
