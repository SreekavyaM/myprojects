package org.capgemini.assignments;

public class MyClass {
	public static void main(String[] args) {
		System.out.println("Hello world");
	}
}
