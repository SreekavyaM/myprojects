package com.flp.pms.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;
import com.flp.pms.service.IProductServiceImp;

public class SaveProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	IProductServiceImp imp=new IProductServiceImp();

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String productname = request.getParameter("product");
		String descriptn = request.getParameter("disc");
		String manufactdate = request.getParameter("mdate");
		String expdate = request.getParameter("edate");
		String mrp = request.getParameter("mrp");
		String catid = request.getParameter("category");
		String subcatid = request.getParameter("subcategory");
		String supid = request.getParameter("supplier");
		String rating = request.getParameter("rating");
		String qty = request.getParameter("qty");
		
		
		SimpleDateFormat sdf=new SimpleDateFormat("YYYY-MM-dd");
		Product product=new Product();
		try {
			Date mandat=sdf.parse(manufactdate);
			Date exdat=sdf.parse(expdate);
			
			product.setManufacturing_date(mandat);
			product.setExpiry_date(exdat);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		Double maxRp = Double.parseDouble(mrp);
		int categoryId = Integer.parseInt(catid);
		int sbcategoryId = Integer.parseInt(subcatid);
		int supId = Integer.parseInt(supid);
		float rate = Float.parseFloat(rating);
		int quantity = Integer.parseInt(qty);
		
		
		product.setProductName(productname);
		product.setDescription(descriptn);
		
		product.setMaxRetailPrice(maxRp);
		product.setQuantity(quantity);
		product.setRating(rate);
		
		Category category=null;
		List<Category> cat=imp.getAllCategory();
		for(Category category1:cat)
			if(category1.getCategory_Id()==categoryId)
				category=category1;
		product.setCategory(category);
		
		SubCategory subCategory=null;
		List<SubCategory> subcat=imp.getAllSubCategory();
		for(SubCategory subcategory1:subcat)
			if(subcategory1.getSub_category_Id()==sbcategoryId)
				subCategory=subcategory1;
		product.setSubCategory(subCategory);
		
		Supplier supplier=null;
		List<Supplier> sup=imp.getAllSuppliers();
		for(Supplier sup1:sup)
			if(sup1.getSupplier_Id()==supId)
				supplier=sup1;
		product.setSupplier(supplier);
		
		


		String[] discountIds=request.getParameterValues("discount");
		List<Discount> discounts=imp.getAllDiscounts();
		List<Discount> discounts1=new ArrayList<>();
		for(Discount discount1:discounts)
			for(String iD: discountIds)
				if(Integer.parseInt(iD)==discount1.getDiscount_Id())
					discounts1.add(discount1);
		
		product.setDiscounts(discounts1);
		imp.addProduct(product);
		
	}

}
