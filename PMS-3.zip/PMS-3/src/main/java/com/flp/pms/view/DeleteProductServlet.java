package com.flp.pms.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.service.IProductServiceImp;

public class DeleteProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IProductServiceImp imp = new IProductServiceImp();

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		String id = request.getParameter("delete");
		int productId = Integer.parseInt(id);
		imp.deleteProduct(productId);

	}

}
