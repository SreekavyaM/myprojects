package com.flp.pms.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.dao.ProductDaoImpJDBC;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;

public class IProductServiceImp implements IProductService {
	IProductDao iProductDao = new ProductDaoImpJDBC();

	public List<Category> getAllCategory() {
		return iProductDao.getAllCategory();
	}

	public List<SubCategory> getAllSubCategory() {
		return iProductDao.getAllSubCategory();
	}

	public List<Discount> getAllDiscounts() {

		return iProductDao.getAllDiscounts();
	}

	public List<Supplier> getAllSuppliers() {
		return iProductDao.getAllSuppliers();
	}

	public void addProduct(Product product) {

		iProductDao.addProduct(product);
	}

	public int generateProductId() {
		return (int) (Math.random() * 10000);
	}

	public void deleteProduct(int productId) {

		List<Product> products = iProductDao.getAllProducts();
		for (Product product : products)
			if (product.getProductId() == productId)
				iProductDao.deleteProduct(productId);

	}

	public List<Product> getAllProductList() {

		return iProductDao.getAllProducts();

	}

	public List<Product> searchByproductname(String productname) {

		List<Product> product = getAllProductList();
		List<Product> product1 = new ArrayList<>();
		for (Product products : product)
			if (products.getProductName().equals(productname))
				product1.add(products);
		
		return product1;

	}

	public List<Product> searchBySupplier(String supplierName) {

		List<Product> product = getAllProductList();
		List<Product> product1 = new ArrayList<>();
		for (Product products : product)
			if (products.getSupplier().getFirstName().equals(supplierName))
				product1.add(products);
		System.out.println(product1);
		
		return product1;
	}

	public List<Product> searchByCategory(String categoryName) {

		List<Product> product = getAllProductList();
		List<Product> product1 = new ArrayList<>();
		for (Product products : product)
			if (products.getCategory().getCategory_Name().equals(categoryName))
				product1.add(products);
		
		return product1;
		

	}

	public List<Product> searchBySubcategory(String supplierName) {

		List<Product> product = getAllProductList();
		List<Product> product1 = new ArrayList<>();
		for (Product products : product)
			if (products.getSubCategory().getSub_category_Name().equals(supplierName))
				product1.add(products);
		System.out.println(product1);
		return product1;
	}

	public List<Product> searchByRating(float rating) {

		List<Product> product = getAllProductList();
		List<Product> product1 = new ArrayList<>();
		for (Product products : product)
			if (products.getRating() == (rating))
				product1.add(products);
		System.out.println(product1);
		return product1;

	}

	public Product searchByproductId(int pId) {
		Product newProduct = null;
		List<Product> product = getAllProductList();
		for (Product products : product) {
			if (products.getProductId() == (pId)) {
				newProduct = products;
			}

		}
		return newProduct;

	}

	public void updateProductName(Product p, String name) {
		iProductDao.updateProductName(p, name);

	}

	public void updateProductCategory(Product p, int c) {
		iProductDao.updateProductCategory(p, c);

	}

	public void updateManufacturingDate(Product p, Date date) {
		iProductDao.updateManufacturingDate(p, date);

	}

	public void updateExpiryDate(Product p, Date date) {
		iProductDao.updateExpiryDate(p, date);

	}

	public void updateMaxRetailPrice(Product p, double mrp) {
		iProductDao.updateMaxRetailPrice(p, mrp);

	}

   @Override
	public void storeJson(String prjson) {
		iProductDao.storeJson( prjson);
	}

@Override
public String getJsonProduct() {
	
	return iProductDao.getJsonProduct();
}

	

}
