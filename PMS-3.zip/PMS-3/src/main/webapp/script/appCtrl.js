app.controller("myController", function($scope,$http) {
	$scope.getcategory = function() {
		
		
		var url = 'http://localhost:8095/PMS-3/CategoryServlet';
		$http.get(url).success(function(response) {
			$scope.cats = response;
		}).error(function(msg) {
			$scope.cats = msg;
		});

		
		
		var url = 'http://localhost:8095/PMS-3/SubcategoryServlet';
		$http.get(url).success(function(response) {
			$scope.subcats = response;
		}).error(function(msg) {
			$scope.subcats = msg;
		});

				var url = 'http://localhost:8095/PMS-3/DiscountServlet';
		$http.get(url).success(function(response) {
			$scope.discounts = response;
		}).error(function(msg) {
			$scope.discounts = msg;
		});
		
		

		var url = 'http://localhost:8095/PMS-3/SupplierServlet';
	$http.get(url).success(function(response) {
		$scope.suppliers = response;
	}).error(function(msg) {
		$scope.suppliers = msg;
	});
		
		
	
	var url = 'http://localhost:8095/PMS-3/ViewAllServlet';
	$http.get(url).success(function(response) {
		
		$scope.products = response;
	}).error(function(msg) {
		$scope.products = msg;
	});
		
	
	var url = 'http://localhost:8095/PMS-3/SearchResultServlet';
	$http.get(url).success(function(response) {
		
		$scope.sproducts = response;
	}).error(function(msg) {
		$scope.sproducts = msg;
	});
	
		
	};
});
