package org.cap.test;

public interface GoodTestCategories {

}
