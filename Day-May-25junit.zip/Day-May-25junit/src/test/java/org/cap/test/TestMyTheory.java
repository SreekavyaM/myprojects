package org.cap.test;

import static org.junit.Assert.*;

import org.cap.trackingservice.TrackingService;
import org.junit.Assume;
import org.junit.Test;
import org.junit.experimental.theories.DataPoint;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;


@RunWith(Theories.class)
public class TestMyTheory {
	
	//TrackingService service=new TrackingService();
	
	/*private static int num;*/
	/*public TestMyTheory(int num){
		this.num=num;
	
	}*/

	/*private int a,b;
	
	public TestMyTheory(int a,int b){
		this.a=a;
		this.b=b;
	}
	*/
	
	@DataPoints
	public static int[] data(){
		return new int[]{1,2,0,14,-5};
	}

	@Theory
	public void testTheory(int a,int b){
		//int a=0,b=0;
		System.out.println(a+"-->" + b);
		
		Assume.assumeTrue(a>0 && b>0);
		assertTrue(a+b>0);
		
		
		/*service.produceProduct(num);
		
		Assume.assumeTrue(num>0);
		assertTrue(service.getTotal()>0);
		*/
	}
	
	
}
