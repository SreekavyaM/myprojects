package org.cap.test;

import static org.junit.Assert.*;

import org.junit.Assume;
import org.junit.Test;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;
@RunWith(Theories.class)
public class TestThery {
	
	Integer a,b;
	@DataPoints
	public static Integer[] data(){
		return new Integer[]{1,2,7,4,5};
	}
	
	@Theory
	public void testTheory(){
		Assume.assumeTrue(a>0 && b>0);
		assertTrue(a+b>0);
	}

}
