package org.cap.test;

import org.junit.internal.TextListener;
import org.junit.runner.JUnitCore;

public class TestRunnerDemo {

	public static void main(String[] args) {
		
		JUnitCore jcore=new JUnitCore();
		jcore.addListener(new TextListener(System.out));
		jcore.run(TrackingServiceTestCase.class);

	}

}
