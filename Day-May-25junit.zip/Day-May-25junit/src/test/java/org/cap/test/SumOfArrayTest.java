package org.cap.test;

import static org.junit.Assert.*;

import org.junit.Test;
import org.test.assignments.SumOfArrayElements;

public class SumOfArrayTest {

	SumOfArrayElements s=new SumOfArrayElements();
	@Test
	public void test() {
		//s.arraySum();


	}

}
