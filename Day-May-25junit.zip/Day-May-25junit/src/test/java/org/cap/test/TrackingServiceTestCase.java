package org.cap.test;

import static org.junit.Assert.*;

import org.cap.trackingservice.InvalidGoalException;
import org.cap.trackingservice.TrackingService;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;

public class TrackingServiceTestCase {
	
	TrackingService service;
	
	@Before
	public void createServiceIntance(){
		System.out.println("TestCase Started");
		service=new TrackingService();
	}
	
	@After
	public void afterTestCase(){
		System.out.println("TestCase Over");
	}
	
	@BeforeClass
	public static void setUp(){
		System.out.println("Class loaded with supporting instance");
	}
	
	@AfterClass
	public static void tearDown(){
		System.out.println("Class object destroyed after completion!");
	}

	@Test
	@Category(GoodTestCategories.class)
	public void whenIncreaseProductIncreaseTotal(){
		service.produceProduct(10);
		
		assertEquals(0, service.getTotal());
	}
	
	
	@Test
	@Category(GoodTestCategories.class)
	public void whenDecreaseProductDecreaseTotal(){
		service.consumeProduct(5);
		
		assertEquals(0, service.getTotal());
	}
	
	@Category(BadTestCategories.class)
	@Test(timeout=50)
	public void testmyLoop(){
		
		
		assertEquals(6, service.myLoop());
	}
	
	@Ignore
	@Test(expected=NullPointerException.class)
	public void testExceptionSetGoal() throws InvalidGoalException{
		service.setGoal(0);
	}

}
