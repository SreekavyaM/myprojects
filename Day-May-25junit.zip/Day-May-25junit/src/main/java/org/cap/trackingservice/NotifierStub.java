package org.cap.trackingservice;

public class NotifierStub implements Notifier{

	public boolean send(String msg) {
		
		return true;
	}

}
