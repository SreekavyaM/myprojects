package org.cap.trackingservice;

import java.util.ArrayList;
import java.util.List;

public class TrackingService {
	
	private int id;
	private int total;
	private int goal;
	private List<Product> products=new ArrayList<Product>();
	private int itemHistoryId=0;
	private Notifier notifier;
	
	public TrackingService(){}
	
	public TrackingService(Notifier notifier){
		this.notifier=notifier;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getGoal() {
		return goal;
	}
	
	
	public void setGoal(int goal) throws InvalidGoalException{
		if(goal<=0)
			throw new InvalidGoalException("Goal should be positive!");
		
		this.goal = goal;
	}
	
	
	public List<Product> getProducts() {
		return products;
	}
	public void setProducts(List<Product> products) {
		this.products = products;
	}
	public int getItemHistoryId() {
		return itemHistoryId;
	}
	public void setItemHistoryId(int itemHistoryId) {
		this.itemHistoryId = itemHistoryId;
	}
	
	
	public void produceProduct(int amount){
		total+=amount;
		products.add(new Product(itemHistoryId++, amount, total, "produce"));
		
		
		if(total>goal)
		{
			String msg;
			boolean notifierStatus=notifier.send("Goal Met!");
			msg="Goal Success:Goal Met!";
			
			if(!notifierStatus)
				msg="Goal_Error: Goal Met!";
			
			products.add(new Product(itemHistoryId++,amount , total, msg));
		}
		
	}
	
	public void consumeProduct(int amount){
		if(amount<0)
			total=0;
		else{
		total-=amount;
			if(total<0)
				total=0;
		}
		products.add(new Product(itemHistoryId++, amount, total, "consume"));
		
		
	}
	
	
	public long myLoop(){
		long sum=0;
		for(long i=0;i<=3l;i++){
			sum+=i;
		}
			return sum;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
