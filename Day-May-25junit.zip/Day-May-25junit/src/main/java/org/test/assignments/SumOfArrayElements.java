package org.test.assignments;

public class SumOfArrayElements {
	private int sum;
	
	public void arraySum()
	{
		int arr[]=new int[5];

		for(int i=0;i<=arr.length;i++)
		{
			sum=arr[i]+arr[i+1];
		}
		System.out.println(sum);
	}
	
}

