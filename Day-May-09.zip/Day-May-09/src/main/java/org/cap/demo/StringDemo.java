package org.cap.demo;

public class StringDemo {
	public static void main(String[] args) {
		
		//String str1="tom";
		
		String str1=new String("tom");
		String str2="tom";
		System.out.println(str1.equals(str2));
		System.out.println(str1==str2);
	}

}
