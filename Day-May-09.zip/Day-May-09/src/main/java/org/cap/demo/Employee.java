package org.cap.demo;

import java.util.Scanner;

public class Employee {
	private int empId;
	private String firstName;
	private String lastName;
	private double salary;
	private Weekdays holiday;

	public void getDetails() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter employee id:");
		empId = sc.nextInt();

		System.out.println("Enter first name:");
		firstName = sc.next();

		System.out.println("Enter lastname:");
		lastName = sc.next();
		System.out.println("Enter salary:");
		salary = sc.nextDouble();
		System.out.println("Choose your holiday(First 3 letters of the day):");
		String choice = sc.next();

		switch (choice) {
		case "sun":
			holiday = Weekdays.SUN;
			break;

		case "mon":
			holiday = Weekdays.MON;
			break;

		case "tue":
			holiday = Weekdays.TUE;
			break;

		case "wed":
			holiday = Weekdays.WED;
			break;

		case "thu":
			holiday = Weekdays.THU;
			break;

		case "fri":
			holiday = Weekdays.FRI;
			break;

		case "sat":
			holiday = Weekdays.SAT;
			break;

		}

	}

	public void printDetails() {
		System.out.println("Employee details");
		System.out.println("-----------------");
		System.out.println("First name is:" + firstName);
		System.out.println("Last name:" + lastName);
		System.out.println("salary:" + salary);
		System.out.println(holiday);

	}

}
