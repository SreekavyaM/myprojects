package org.cap.demo;

public class MainClassEmp {
	
	public static void main(String[] args) {
		Employee1 emp1=new Employee1(123, "sree", "kavya", 6887733);
		
		Employee1 emp2=new Employee1(345, "libin", "alex", 76587665);
		
		
		
		System.out.println(emp1.equals(emp2));
		System.out.println(emp1==emp2);
		
	}

}
