package org.cap.demo;

public enum Weekdays {
	SUN("sun"), MON("mon"), TUE("tue"), WED("wed"), THU("thu"), FRI("fri"), SAT("sat");
	private String dayValue;

	Weekdays(String dayValue) {
		this.dayValue = dayValue;
	}

	public String getDayValue() {
		return dayValue;
	}

}
