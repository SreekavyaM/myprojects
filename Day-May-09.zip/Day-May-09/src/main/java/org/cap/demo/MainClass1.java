package org.cap.demo;

public class MainClass1 {
	public static void main(String[] args) {
		
		Employee emp=new Employee();
		emp.getDetails();
		emp.printDetails();
		

	}

}
