package org.cap.demo;

public class Employee1 {
	private int empId;
	private String firstName;
	private String lastName;
	private double salary;

	public boolean equals(Object obj)
	{
		Employee1 emp=(Employee1)obj;
	if(this==emp)
		return true;
	else{
		if(this.empId==emp.empId)
		{
			if(this.firstName.equals(emp.firstName))
			{
				if(this.lastName.equals(emp.lastName))
					return true;
			}return false;
		}return false;
		
	}
	}
	
	public Employee1(int empId, String firstName, String lastName, double salary) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
	}

}
