package org.cap.assignments;


public class Account {
	
	private String accountname;
	private int accountNo;
	private String accType;
	private double amount;
	
	
	public Account(int accountNo,String accountname, String accType, double amount) {
		super();
		this.accountname = accountname;
		this.accountNo = accountNo;
		this.accType = accType;
		this.amount = amount;
	}
	
	@Override
	public String toString() {
		return "Account [accountname=" + accountname + ", accountNo=" + accountNo + ", accType=" + accType + ", amount="
				+ amount + "]";
	}

	public String getAccountname() {
		return accountname;
	}
	public void setAccountname(String accountname) {
		this.accountname = accountname;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	

	

	
}
