package org.cap.assignments;

public class AccountRepository {
	 Account[] account=new Account[100];
	
	
}
