package org.cap.assignments;

import java.io.InputStreamReader;
import java.util.Date;
import java.util.Scanner;

public class TransactionDAOImplementation implements TransactionDAO {

	private String accountname;
	private int accountNo;
	private String accType;
	private double amount;
	Scanner s1 = new Scanner(System.in);
	int tot = 0;
	int max_limit = 100;
	AccountRepository act = new AccountRepository();

	@Override
	public void saveAccount(Account account[]) {

		if (tot > max_limit) {
			System.out.println("Sorry we cannot admit you in our bank");

		}

		else // Allows to create new ACCOUNT
		{
			tot++; // Incrementing Total Record

			accountNo = tot;
			System.out.println("Account Number :  " + tot);

			System.out.print("Enter Name :  ");

			accountname = s1.nextLine();

			accType = "Current Account";
			System.out.println("Account Type : " + accType);

			System.out.print("Enter Initial  Amount to be deposited : ");

			amount = s1.nextDouble();
			
				account[tot] = new Account(accountNo, accountname, accType, amount);
				//System.out.println(AccountRepository.account[tot]);
				
		
			
			System.out.println("Account is opened for you");

		}
	}

	@Override
	public void withdraw(Account account[]) {
		System.out.println("Enter account no");
		int acc1 = s1.nextInt();
		
		//for (int i = 0; i <tot; i++) {
			if (acc1 == account[tot].getAccountNo()) {
		
				System.out.println("enter balance to be withdrawn");
				double amt = s1.nextDouble();
				amount = amount - amt;
				System.out.println("Remaining balance" + amount);
			} else {
				System.out.println("account no is invalid");
			}

	}

	//}

	@Override
	public void deposit(Account account[]) {
		System.out.println("Enter account no");
		int acc1 = s1.nextInt();
		for (int i = 0; i < tot; i++) {
			if (acc1 == account[tot].getAccountNo()) {

				System.out.println("enter balance to be deposited");
				double amt = s1.nextDouble();
				amount = amount + amt;
				System.out.println("New balance" + amount);
			} else {
				System.out.println("account no is invalid");
			}

		}

	}
}
