package org.cap.assignments;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		Employee emp = null;// reference is created for parent..based on input
							// it is calling method

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter 1 for weekly salary and 2 for monthly salary:");
		int n = scanner.nextInt();

		if (n == 1) {
			emp = new WeeklySalaryEmployee();
			emp.getEmployeeDetails();
			emp.printEmployeeDetails();
			emp.calculateSalary();

		} else if (n == 2) {
			emp = new MonthlySalaryEmployee();
			emp.printEmployeeDetails();
			emp.calculateSalary();

		} else {
			System.out.println("Invalid input");
			System.exit(0);
		}

	}
}
