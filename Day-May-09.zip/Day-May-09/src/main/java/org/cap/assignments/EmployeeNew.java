package org.cap.assignments;

public interface EmployeeNew {
	public void getEmployeeDetails();

	public void printEmployeeDetails();

	public double calculateSalary();

}
