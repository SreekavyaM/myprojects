package org.cap.assignments;

public class StringAssignment {
	public static void main(String[] args) {
		String str="CapgeminiIndia";
		
		System.out.println(str.charAt(5));
		System.out.println(str.compareTo("capge"));
		
		System.out.println(str.compareToIgnoreCase(str));
		System.out.println(str.concat("private")); 
		
		System.out.println(str.contains("cap"));
		System.out.println(str.getBytes());
		
		
		System.out.println(str.indexOf('n'));
		System.out.println(str.intern());
		System.out.println(str.isEmpty());
		
		System.out.println(str.lastIndexOf('g'));
		
		System.out.println(str.length());
		
		System.out.println(str.matches("gemini"));
		System.out.println(str.replace('a', 's'));
		System.out.println(str.replaceAll("Cap", "Sree"));
		
		System.out.println(str.replaceFirst("gemini", "first"));
		System.out.println(str.split("ap"));
		
		System.out.println(str.startsWith("gem"));
		System.out.println(str.subSequence(0, 4));
		System.out.println(str.substring(7));
		
		System.out.println(str.toCharArray());
		System.out.println(str.toLowerCase());
		System.out.println(str.toUpperCase());
		System.out.println(str.trim());
		System.out.println(str.valueOf('a'));
		
	}

}
