package org.cap.assignments;

import java.util.Scanner;

public class WeeklySalaryNew implements EmployeeNew  {
	
	private int empId;
	private String firstName;
	private String lastName;

	public void getEmployeeDetails() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter employee id:");
		 empId=sc.nextInt();
		
		System.out.println("Enter first name:");
		 firstName=sc.next();
		System.out.println("Enter last name:");
	 lastName=sc.next();
		
		
	}

	public void printEmployeeDetails() {
		 System.out.println("Employee Details");
			System.out.println("-----------------");
			System.out.println(empId);
			System.out.println(firstName);
			System.out.println(lastName);
			
		
	}

	public double calculateSalary() {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter no of hours:");
		double noOfHours=sc.nextDouble();
		System.out.println("enter wages per hour");
		double wagesPerHour=sc.nextDouble();
		
		return wagesPerHour*noOfHours;
		
	}
		 
	

}
