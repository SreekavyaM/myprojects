package org.cap.assignments;

import java.util.Scanner;

public class MonthlySalaryEmployee extends Employee {
	
	
	//To calculate salary
	public void calculateSalary() {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter no of days:");
		float noOfDays=sc.nextFloat();
		System.out.println("enter wages per day:");
		float wagesPerDay=sc.nextFloat();
		
		float salary=noOfDays*wagesPerDay;
		System.out.println("salary is:"+salary);
		
	}
}
