package org.cap.assignments;

import java.util.Scanner;

public class BootClass {
	public static void main(String[] args) {
		UserInteraction user=new UserInteraction();
		user.enterChoice();
	}

}
