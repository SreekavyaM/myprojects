package org.cap.assignments;

import java.util.Scanner;

public class UserInteraction {
	public void enterChoice() {
		Scanner s1 = new Scanner(System.in);
		 Account[] account=new Account[100];
		 TransactionDAOImplementation trans = new TransactionDAOImplementation();
		 for(;;)
		 {
			 System.out.println("Enter 1 to create new account");

				System.out.println("Enter 2 to withdraw amount");

				System.out.println("Enter 3 to deposit money");
				int option = s1.nextInt();

				

				if (option == 1) {
					trans.saveAccount(account);
				} else if (option == 2) {
					trans.withdraw(account);

				} else if (option == 3) {
					trans.deposit(account);

				}
		 }
		
	}
}
