package org.cap.assignments;

public interface TransactionDAO {


	void saveAccount(Account[] account);

	void withdraw(Account[] account);

	void deposit(Account[] account);

}
