package org.cap.assignments;

import java.util.Scanner;

public class WeeklySalaryEmployee extends Employee {
	
	private float noOfHours;
	private float wagesPerHour;

	@Override
	//To calculate salary
	public void calculateSalary() {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter no of hours:");
		 noOfHours=sc.nextFloat();
		System.out.println("enter wages per hour");
		 wagesPerHour=sc.nextFloat();
		
		double salary=noOfHours*wagesPerHour;
		System.out.println("salary is:"+salary);
		
		
	}

}
