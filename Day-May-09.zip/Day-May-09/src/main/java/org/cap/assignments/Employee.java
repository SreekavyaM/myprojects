package org.cap.assignments;

import java.util.Scanner;

public abstract class Employee {
	
	private int empId;
	private String firstName;
	private String lastName;
	
	//To get employee details
	public void getEmployeeDetails()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter employee id:");
		 empId=sc.nextInt();
		
		System.out.println("Enter first name:");
		 firstName=sc.next();
		System.out.println("Enter last name:");
		 lastName=sc.next();
		
		
	}
	//To print employee details
	public void printEmployeeDetails()
	{
		 System.out.println("Employee Details");
			System.out.println("-----------------");
			System.out.println(empId);
			System.out.println(firstName);
			System.out.println(lastName);
			
	}
	 public abstract  void calculateSalary();
	
	
	
}
