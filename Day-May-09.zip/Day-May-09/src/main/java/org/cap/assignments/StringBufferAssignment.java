package org.cap.assignments;

public class StringBufferAssignment {

	public static void main(String[] args) {
		
		StringBuffer st=new StringBuffer();
		
		System.out.println(st.append("sreeeekavya"));
		System.out.println(st.delete(0, 3));
		System.out.println(st.deleteCharAt(2));
		st.ensureCapacity(0);
		System.out.println(st.indexOf("ka"));
		System.out.println(st.insert(0, 's'));
		System.out.println(st.reverse());
		
	}

}
