package org.capgemini.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;





public class JDBCDemo {

	public static void main(String[] args) {
		
		Connection conn=null;
		try {
			
			//Load Driver Class
			Class.forName("com.mysql.jdbc.Driver");
			
			//Establish Connection
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/capdb","root","admin");
			
			
			//Statement stmt=conn.createStatement();
			//String sql="insert into employee values(193,'Kenn','Thomson',23000,2)";
		//	String sql="insert into employee values(?,?,?,?,?)";
			
			//String sql="update employee set lastname=? where empid=?";
			String sql="delete from employee where empid=?";
			PreparedStatement pst=conn.prepareStatement(sql);
			
		/*	pst.setInt(1, 1003);
			pst.setString(2, "Jack");
			pst.setString(3, "keen");
			pst.setDouble(4, 25900);
			pst.setInt(5, 1);*/
			
			/*pst.setString(1, "Silk");
			pst.setInt(2, 198);*/
			
			pst.setInt(1, 198);
			
			int result=pst.executeUpdate();
			
			if(result>0)
				System.out.println("Row Deleted");
					
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		

	}

}
