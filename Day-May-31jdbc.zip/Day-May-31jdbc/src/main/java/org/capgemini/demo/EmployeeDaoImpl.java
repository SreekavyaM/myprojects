package org.capgemini.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class EmployeeDaoImpl implements EmployeeDao {

	public int addEmployee(Employee employee) {
		int count = 0;
		String query1 = "insert into employee values(?,?,?,?,?,?)";
		try {
			PreparedStatement pst = getMySQlConnection().prepareStatement(query1);
			pst.setInt(1, employee.getEmpId());
			pst.setString(2, employee.getFirstName());
			pst.setString(3, employee.getLastName());
			pst.setDouble(4, employee.getSalary());
			pst.setString(5, employee.getEmail());
			pst.setInt(6, employee.getDepartmentId().getDepartmentId());

			count = pst.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return count;

	}

	public Connection getMySQlConnection() {

		Connection conn = null;
		try {

			// Load Driver Class
			Class.forName("com.mysql.jdbc.Driver");

			// Establish Connection
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/capdb", "root", "root");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return conn;

	}

	public ResultSet viewAllEmployee() {
		Statement stmt = null;
		ResultSet rs = null;
		String query2 = "select * from employee";
		try {
			stmt = getMySQlConnection().createStatement();
			rs = stmt.executeQuery(query2);
			while (rs.next()) {
				System.out.println(rs.getInt(1));
				System.out.println(rs.getString(2));
				System.out.println(rs.getString(3));
				System.out.println(rs.getDouble(4));
				System.out.println(rs.getString(5));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return rs;
	}

	public void deleteEmployee(int id) {
		int count = 0;
		String query3 = "delete from employee where empid=id";
		
	
		
		try {
			PreparedStatement pst = getMySQlConnection().prepareStatement(query3);
			
			count=pst.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
