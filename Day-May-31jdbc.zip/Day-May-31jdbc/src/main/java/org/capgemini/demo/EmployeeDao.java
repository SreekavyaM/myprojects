package org.capgemini.demo;

import java.sql.ResultSet;

public interface EmployeeDao {
	
	public int addEmployee(Employee employee);
	
	public ResultSet viewAllEmployee();
	
	public void deleteEmployee(int id);

}
