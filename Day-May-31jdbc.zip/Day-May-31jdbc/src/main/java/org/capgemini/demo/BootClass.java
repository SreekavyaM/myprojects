package org.capgemini.demo;

import java.util.Scanner;

public class BootClass {
	Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		BootClass boot = new BootClass();
		boot.viewMenu();

	}

	public void viewMenu() {

		UserInteraction ui = new UserInteraction();
		EmployeeDao empDao = new EmployeeDaoImpl();
		for (;;) {

			System.out.println("1.View all employees" + "\t" + "2.Update employee details"

					+ "\t" + "3.Insert new Employee" + "\t" + "4.Delete Employee");

			System.out.println("Enter your choice");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				empDao.viewAllEmployee();
				break;
			case 2:
				break;
			case 3:
				Employee emp = ui.getEmployee();
				int count = empDao.addEmployee(emp);
				System.out.println(ui.printMessage(count));
				break;
			case 4:
				empDao.deleteEmployee(ui.deleteEmployee());
				break;
			}
		}

	}

}
