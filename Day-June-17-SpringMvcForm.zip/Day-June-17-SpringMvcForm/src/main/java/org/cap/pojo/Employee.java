package org.cap.pojo;

import java.util.Date;

import javax.validation.constraints.Future;
import javax.validation.constraints.Min;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

public class Employee {
	
	private int empId;

	@NotEmpty(message="*Please enter FirstName!")
	private String firstName;
	private String lastName;
	
	@Range(min=2000,max=100000,message="*Salary should be between 2000 and 1lak.")
	private double salary;
	
	@Length(min=6,max=15,message="*Please enter password between 6 to 15 chars")
	private String empPassword;
	
	@Email(message="*Please enter valid Email!")
	private String empEmail;
	
	@Past(message="*Please enter past Date!")
	private Date empDob;
	
	@Future(message="*Please enter Future date!")
	private Date empDoj;
	
	@Length(min=10,message="*Please enter 10 digits!")
	private String contactNo;
	
	
	
	public Employee(){}



	public Employee(int empId, String firstName, String lastName, double salary, String empPassword, String empEmail,
			Date empDob, Date empDoj, String contactNo) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.empPassword = empPassword;
		this.empEmail = empEmail;
		this.empDob = empDob;
		this.empDoj = empDoj;
		this.contactNo = contactNo;
	}



	public int getEmpId() {
		return empId;
	}



	public void setEmpId(int empId) {
		this.empId = empId;
	}



	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public double getSalary() {
		return salary;
	}



	public void setSalary(double salary) {
		this.salary = salary;
	}



	public String getEmpPassword() {
		return empPassword;
	}



	public void setEmpPassword(String empPassword) {
		this.empPassword = empPassword;
	}



	public String getEmpEmail() {
		return empEmail;
	}



	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}



	public Date getEmpDob() {
		return empDob;
	}



	public void setEmpDob(Date empDob) {
		this.empDob = empDob;
	}



	public Date getEmpDoj() {
		return empDoj;
	}



	public void setEmpDoj(Date empDoj) {
		this.empDoj = empDoj;
	}



	public String getContactNo() {
		return contactNo;
	}



	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}



	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", firstName=" + firstName + ", lastName=" + lastName + ", salary=" + salary
				+ ", empPassword=" + empPassword + ", empEmail=" + empEmail + ", empDob=" + empDob + ", empDoj="
				+ empDoj + ", contactNo=" + contactNo + "]";
	}
	
	

}
